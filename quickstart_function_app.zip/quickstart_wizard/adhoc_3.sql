@orders  =
    EXTRACT customer_id          string,
            sku           string,
			order_date	DateTime,
            product_quantity          string,
			amount_spent	float,
			latitude	string,
			longitude	string,
			payment_mode string			
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/orders/{*}.csv"   
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@products  =
    EXTRACT sku          string,
            product_category           string,
			link	         string,
            company          string,
			price	float,
			release_date	DateTime
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/products/{*}.csv"
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@rs1=
	SELECT prod.product_category, COUNT(*) AS number_of_orders
	FROM @orders AS ord	
	JOIN @products AS prod
	ON ord.sku == prod.sku
	GROUP BY prod.product_category;

OUTPUT @rs1
    TO "wasb://publish@storage_account_name.blob.core.windows.net/datasets/adhoc/ADHOC_3_Product_Category_wise_Order_Distribution.csv"
	ORDER BY number_of_orders DESC
    USING Outputters.Csv(outputHeader: true);