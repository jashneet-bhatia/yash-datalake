# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$name = $requestBody.name

# GET method: each querystring parameter is its own variable
if ($req_query_name) 
{
    $name = $req_query_name 
}

# Out-File -Encoding Ascii -FilePath $res -inputObject "Hello $name"
# Login-AzureRmAccount
# $subscriptionId = "18bc600e-57c7-4ea5-b64a-bb62f1f34d2c"
# Set-AzureRmContext -SubscriptionId $subscriptionId
$appName = "demopsapp"
$uri = "http://demopsapp"
$secret = "demopsapp"
#$azureAdApplication = New-AzureRmADApplication -DisplayName $appName -HomePage $Uri -IdentifierUris $Uri -Password $secret
New-AzureRmADApplication -DisplayName $appName -HomePage $Uri -IdentifierUris $Uri -Password $secret
Write-Output "Save these values for using them in your application"
Write-Output "Subscription ID:" (Get-AzureRmContext).Subscription.SubscriptionId
Write-Output "Tenant ID:" (Get-AzureRmContext).Tenant.TenantId
Write-Output "Application ID:" $azureAdApplication.ApplicationId.Guid
Write-Output "Application Secret:" $secret
