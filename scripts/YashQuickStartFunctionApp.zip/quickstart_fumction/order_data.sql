@orders  = EXTRACT customer_id string,
     sku string, order_date	string,
     product_quantity string, amount_spent float,latitude string,longitude string,payment_mode string
	 FROM "wasb://raw@datalakeresources.blob.core.windows.net/datasets/orders/order_data.csv"  
	 USING Extractors.Csv(skipFirstNRows:1);  

@rs1 =  SELECT payment_mode, (SUM(amount_spent)/1000) AS amount_spent, COUNT(*) AS number_of_orders 
     FROM @orders GROUP BY payment_mode;  

OUTPUT @rs1  TO "wasb://raw@datalakeresources.blob.core.windows.net/datasets/orders/order_usql.csv" USING Outputters.Csv();
