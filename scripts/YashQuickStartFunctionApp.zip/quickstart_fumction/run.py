import os
import json, time
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))
import requests
# import pprint
# import adal

############################################################
from azure.mgmt.datalake.analytics.job.models import JobInformation, JobState, USqlJobProperties
from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.datalake.analytics.job import DataLakeAnalyticsJobManagementClient

from utilities import df_run_id, adla_run_job, df_status, adla_run_job_status

response = open(os.environ['res'], 'w')



env = os.environ


# Get HTTP METHOD
http_method = env['REQ_METHOD'] if 'REQ_METHOD' in env else "GET"
print http_method

if http_method == 'GET':
    with open('intro.html', 'r') as f:
        returnData = {
            # HTTP Status Code:
            "status": 200,

            # Response Body:
            # "body":"process done",
            "body": f.read(),

            # Send any number of HTTP headers
                "headers": {
            "Content-Type": "text/html",
            "X-Awesome-Header": "YesItIs"
        }
        }
        # print 'first'
        response.write(json.dumps(returnData))

if http_method == 'POST':
    b = open(os.environ['req']).read() if os.environ['req'] else "'a':'b'"
    l = b.split('=')
    # print l
    a = '{"' + l[0] + '":"' + l[1] + '"}'

    #print a
    postreqdata = json.loads(a)
    if postreqdata['name'] == 'fifth':
        with open('fifth.html', 'r') as f:
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": f.read(),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'discover_raw_datasets':
        with open('discover_raw_datasets.html', 'r') as f:
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": f.read(),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))


    elif postreqdata['name'] == 'transform_dataset':
        # df_url = env['raw_to_transformed']
        # run_id = df_run_id(df_url)
        # request_url = "https://management.azure.com/subscriptions/18bc600e-57c7-4ea5-b64a-bb62f1f34d2c/resourceGroups/innovationgroup-BigData/providers/Microsoft.DataFactory/factories/test-if-adf/pipelineruns/" + run_id + "?api-version=2017-03-01-preview"
        # while True:
        #     return_response2 = requests.get(request_url)
        #     jsonresponse2 = return_response2.json()
        #     if (str(jsonresponse2['status']) == 'InProgress'):
        #         print("IN PROGRESS")
        #         time.sleep(2)
        #     else:
        #         print("SUCCEEDED")
        #         break
        with open('run_analytics_job.html', 'r') as f:
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": f.read(),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'publish_dataset':
        with open('order_data.sql','r') as usql:
            script = str(usql.read()).replace('\n','')    
            job_id = adla_run_job(script)
            adla = env['adla']
            jobResult = adla_run_job_status(job_id,adla)
            ################################################
            credentials = ServicePrincipalCredentials(client_id = '30a02443-626a-4518-9c06-f83fa551f984', secret = 'xtiGxTpoQ/l40lDJL7U1WGL3SgYLSHyW/gCivHKfO4s=', tenant = '638456b8-8343-4e48-9ebe-4f5cf9a1997d')
            adlaJobClient = DataLakeAnalyticsJobManagementClient( credentials, 'azuredatalakeanalytics.net')
            
            while(jobResult.state != JobState.ended):
                print('Job is not yet done, waiting. Current state: ' + jobResult.state.value)
                time.sleep(50)
                jobResult = adlaJobClient.job.get(adla, job_id)

            print ('Job finished with result: ' + jobResult.result.value)
        with open('power_bi_details.html', 'r') as f:
            ress = f.read()
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": ress.replace('df_status','U-SQL Job completed'),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'get_dataset':

        df_url = env['discover_raw_datasets']
        run_id_json = df_run_id(df_url)        
        jsonresponse = run_id_json.json()
        #print str(jsonresponse['runId'])
        # print 'df_status '+str(df_status)
        # if df_status != 'In Progress':
        run_id = jsonresponse['runId']
        
        time.sleep(90)
        df_st = df_status(run_id)
        #while df_status(run_id) == 'InProgress': 
        #print df_st
        while True:
            print 'in while loop'
            if df_st not in 'InProgress':
                print 'in if'
                break
            
            df_st = df_status(run_id)
                #time.sleep(3)
                # response.write('df still in Progress')
                                 
        with open('create_transform_datasets.html', 'r') as f:
            ress = f.read()
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": ress.replace('df_status','Datafactory Triggered successfully. Data Moved to raw container.'),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }

        response.write(json.dumps(returnData))
        

    else:
        response.write('invalid request')

response.close()


