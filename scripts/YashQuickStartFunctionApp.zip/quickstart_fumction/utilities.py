import os
import json


import sys, os.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))
import requests
import pprint
import adal

## Use this only for Azure AD service-to-service authentication
from azure.common.credentials import ServicePrincipalCredentials

## Required for Azure Data Lake Analytics job management
from azure.mgmt.datalake.analytics.job import DataLakeAnalyticsJobManagementClient
from azure.mgmt.datalake.analytics.job.models import JobInformation, JobState, USqlJobProperties

## Use these as needed for your application
import logging, getpass, pprint, uuid, time


#postreqdata = json.loads(open(os.environ['req']).read())
#response = open(os.environ['res'], 'w')

def df_run_id(rest_url):

    authority_url = 'https://login.microsoftonline.com/638456b8-8343-4e48-9ebe-4f5cf9a1997d'
    context = adal.AuthenticationContext(authority_url)
    resource = 'https://management.azure.com/'
    client_id = '30a02443-626a-4518-9c06-f83fa551f984'
    client_secret = 'xtiGxTpoQ/l40lDJL7U1WGL3SgYLSHyW/gCivHKfO4s='
    token = context.acquire_token_with_client_credentials(resource, client_id, client_secret)
    #print (token)

    headers ={'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}

    #url = "https://management.azure.com/subscriptions/18bc600e-57c7-4ea5-b64a-bb62f1f34d2c/resourceGroups/innovationgroup-BigData/providers/Microsoft.DataFactory/factories/test-if-adf/pipelines/pipelineToBeExecuteByPythonFunction/createRun?api-version=2017-03-01-preview"
    url = rest_url
    return_response = requests.post(url, headers=headers)
    #print return_response
    #print type(return_response)
    return return_response
    #response.write("datafactory triggered")

def df_status(run_id):
    authority_url = 'https://login.microsoftonline.com/638456b8-8343-4e48-9ebe-4f5cf9a1997d'
    context = adal.AuthenticationContext(authority_url)
    resource = 'https://management.azure.com/'
    client_id = '30a02443-626a-4518-9c06-f83fa551f984'
    client_secret = 'xtiGxTpoQ/l40lDJL7U1WGL3SgYLSHyW/gCivHKfO4s='
    token = context.acquire_token_with_client_credentials(resource, client_id, client_secret)
    #print (token)

    headers ={'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}

    request_url = "https://management.azure.com/subscriptions/18bc600e-57c7-4ea5-b64a-bb62f1f34d2c/resourceGroups/innovationgroup-BigData/providers/Microsoft.DataFactory/factories/test-if-adf/pipelineruns/" +str(run_id)+ "?api-version=2017-09-01-preview"
        # while True:
    return_response2 = requests.get(request_url,headers=headers)
    jsonresponse2 = return_response2.json()
    #print 'jsonresponse2 '+ str(jsonresponse2)
    status = jsonresponse2['status']
    print str(status)
    return status
    

def adla_run_job(script):
    credentials = ServicePrincipalCredentials(client_id = '30a02443-626a-4518-9c06-f83fa551f984', secret = 'xtiGxTpoQ/l40lDJL7U1WGL3SgYLSHyW/gCivHKfO4s=', tenant = '638456b8-8343-4e48-9ebe-4f5cf9a1997d')
    subid= '18bc600e-57c7-4ea5-b64a-bb62f1f34d2c'
    rg = 'innovationgroup-BigData'
    location = 'eastus2' # i.e. 'eastus2'
    adls = 'quickstartadlstore'
    adla = 'quickstartadla'

    adlaJobClient = DataLakeAnalyticsJobManagementClient( credentials, 'azuredatalakeanalytics.net')
    print("hitting usql job")
    # script = """
    # @orders  = EXTRACT customer_id string,
    #     sku string, order_date	string,
    #     product_quantity string, amount_spent float,latitude string,longitude string,payment_mode string
    #     FROM "wasb://raw@datalakeresources.blob.core.windows.net/datasets/orders/order_data.csv"  
    #     USING Extractors.Csv(skipFirstNRows:1);  

    # @rs1 =  SELECT payment_mode, (SUM(amount_spent)/1000) AS amount_spent, COUNT(*) AS number_of_orders 
    #     FROM @orders GROUP BY payment_mode;  

    # OUTPUT @rs1  TO "wasb://raw@datalakeresources.blob.core.windows.net/datasets/orders/order_usql.csv" USING Outputters.Csv();
    # """

    jobId = str(uuid.uuid4())
    jobResult = adlaJobClient.job.create(
        adla,
        jobId,
        JobInformation(
            name='Sample Job',
            type='USql',
            properties=USqlJobProperties(script=script)
        )
    )
    print(jobResult)
    return jobId

def adla_run_job_status(jobId,adla):
    credentials = ServicePrincipalCredentials(client_id = '30a02443-626a-4518-9c06-f83fa551f984', secret = 'xtiGxTpoQ/l40lDJL7U1WGL3SgYLSHyW/gCivHKfO4s=', tenant = '638456b8-8343-4e48-9ebe-4f5cf9a1997d')
    adlaJobClient = DataLakeAnalyticsJobManagementClient( credentials, 'azuredatalakeanalytics.net')
    jobResult = adlaJobClient.job.get(adla, jobId)
    print jobResult
    return jobResult
