@customers  =
    EXTRACT customer_id          string,
            first_name           string,
            last_name            string,
            region          string,
            state   string,
            cbgid   float,
            marital_status  string,
            education_level string,
            age int,
            gender string
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/customers/{*}.csv"
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@orders  =
    EXTRACT customer_id          string,
            sku           string,
			order_date	string,
            product_quantity          string,
			amount_spent	float,
			latitude	string,
			longitude	string,
			payment_mode string			
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/orders/{*}.csv"
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@product  =
    EXTRACT sku          string,
            product_category           string,
            link          string,
            company  string,
            price   float,
            release_date    string      
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/products/{*}.csv"
    USING Extractors.Csv(skipFirstNRows:1, silent: true);

@demographics =
     EXTRACT cbgid          int?,
             state           string,
             population          int?,
             population_density           float?,
             households         int?,
             middle_aged_people        int?,
             household_income            float?,
             bachelors_degrees     int?,
             families_with_children     int?,
             children_under_5     int?,
             owner_occupied     int?,
             marriedcouple_family     int?
     FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/demographics/{*}.csv"
     USING Extractors.Text(delimiter: '|', skipFirstNRows: 1, silent: true);

@age_wise_exp_dist_result_1 =
    SELECT age_grp.customer_id, String.Concat(age_grp.first_name, age_grp.last_name) AS customer_name, age_grp.gender,
        (age_grp.age>= 18 AND age_grp.age < 30) ? "18-29" : 
        (age_grp.age>= 30 AND age_grp.age < 50) ? "30-49" :
        (age_grp.age>= 50 AND age_grp.age < 65) ? "50-64" :
        (age_grp.age>= 65 AND age_grp.age < 80) ? "65-older" :"out of category"
        AS age_grp_category
    FROM @customers AS age_grp
    GROUP BY age_grp.gender, age_grp.age, age_grp.customer_id, age_grp.first_name, age_grp.last_name;

@age_wise_exp_dist_result_2=
    SELECT cust.customer_name,cust.gender, cust.age_grp_category, SUM(ord.amount_spent) AS expenditure
    FROM @age_wise_exp_dist_result_1 AS cust
    JOIN @orders AS ord
    ON ord.customer_id == cust.customer_id
    GROUP BY cust.customer_name,cust.gender, cust.age_grp_category;

@big_spenders_result=
    SELECT String.Concat(cust.first_name,cust.last_name) AS customer_name, ord_num.total_amt_spent AS total_amt_spent, 
        ord_num.avg_amt_spent AS avg_amt_spent,ord_num.number_of_orders 
    FROM
        (SELECT customer_id , SUM(amount_spent) AS total_amt_spent ,AVG(amount_spent) AS avg_amt_spent,
        COUNT(*) AS number_of_orders FROM @orders 
        GROUP BY customer_id) AS ord_num
    JOIN @customers AS cust
    ON ord_num.customer_id == cust.customer_id;

@male_orders=
    SELECT Convert.ToDateTime(orders.order_date).Year AS year, Convert.ToDateTime(orders.order_date).Month AS month, COUNT(*) AS male_orders
    FROM @orders AS orders 
    JOIN @customers AS customers 
    ON orders.customer_id == customers.customer_id 
    WHERE customers.gender == "M"
    GROUP BY Convert.ToDateTime(orders.order_date).Year, Convert.ToDateTime(orders.order_date).Month;

@female_orders=
    SELECT Convert.ToDateTime(orders.order_date).Year AS year, Convert.ToDateTime(orders.order_date).Month AS month, COUNT(*) AS female_orders
    FROM @orders AS orders 
    JOIN @customers AS customers  
    ON orders.customer_id == customers.customer_id 
    WHERE customers.gender == "F"
    GROUP BY Convert.ToDateTime(orders.order_date).Year, Convert.ToDateTime(orders.order_date).Month;

@total_orders=
    SELECT Convert.ToDateTime(orders.order_date).Year AS year, Convert.ToDateTime(orders.order_date).Month AS month, COUNT(*) AS total_orders
    FROM @orders AS orders 
    JOIN @customers AS customers  
    ON orders.customer_id == customers.customer_id 
    GROUP BY Convert.ToDateTime(orders.order_date).Year, Convert.ToDateTime(orders.order_date).Month;

@gender_orders_by_month_result=
    SELECT male_orders,female_orders,total_orders
    FROM @male_orders AS male_orders
    JOIN @female_orders AS female_orders
    ON male_orders.year == female_orders.year AND male_orders.month == female_orders.month
    JOIN @total_orders AS total_orders
    ON male_orders.year == total_orders.year AND male_orders.month ==total_orders.month;
    
@gender_product_category_count_result =
    SELECT cust.gender, prod.product_category, SUM(ord.amount_spent) AS Amount_Spent,COUNT(*) AS gender_product_category_count
    FROM @product AS prod
    JOIN @orders AS ord 
    ON ord.sku == prod.sku
    JOIN @customers AS cust
    ON cust.customer_id == ord.customer_id
    GROUP BY cust.gender, prod.product_category;

@house_hold_income_distribution_result=
   SELECT 
        (household_income < 50000) ? "Under 50K" : 
        (household_income >= 50000 AND household_income < 100000) ? "50k-100k" :
        (household_income >= 100000 AND household_income < 200000) ? "100k-200k" :
        (household_income >= 200000) ? "Above 200k" : "NA"
        AS household_income_category, COUNT(*) AS family_count
    FROM @demographics AS age_grp
    WHERE household_income IS NOT NULL
    GROUP BY (household_income < 50000) ? "Under 50K" : 
        (household_income >= 50000 AND household_income < 100000) ? "50k-100k" :
        (household_income >= 100000 AND household_income < 200000) ? "100k-200k" :
        (household_income >= 200000) ? "Above 200k" : "NA";

@loyal_customer_result =
    SELECT String.Concat(cust.first_name,cust.last_name) AS customer_name, updt_ord_dt.first_order_date,        updt_ord_dt.latest_order_Date,
            (Convert.ToDateTime(updt_ord_dt.first_order_date)-Convert.ToDateTime(updt_ord_dt.latest_order_Date)).TotalDays AS DaysAsCustomer 
    FROM 
        (SELECT updt_ord.customer_id, MIN(updt_ord.formatted_order_date) AS first_order_date, MAX(updt_ord.formatted_order_date) AS latest_order_Date 
        FROM
            (SELECT ord.customer_id,ord.order_date AS formatted_order_date
            FROM @orders AS ord
            GROUP BY ord.customer_id, ord.order_date) AS updt_ord
        GROUP BY updt_ord.customer_id) AS updt_ord_dt
    JOIN @customers AS cust
    ON cust.customer_id == updt_ord_dt.customer_id
    GROUP BY cust.first_name,cust.last_name,updt_ord_dt.first_order_date, updt_ord_dt.latest_order_Date;

@order_distribution_by_day_of_week_result=
    SELECT (int)(ord_dt.updated_order_date).DayOfWeek AS day_of_week,COUNT(*) AS order_distribution 
    FROM (SELECT DateTime.Parse(ord.order_date) AS updated_order_date
    FROM @orders AS ord ) AS ord_dt
    GROUP BY (int)(ord_dt.updated_order_date).DayOfWeek;

@payment_type_result =
    SELECT payment_mode, (SUM(amount_spent)/1000) AS amount_spent, COUNT(*) AS number_of_orders 
    FROM @orders
    GROUP BY payment_mode;

@state_wise_order_distribution_result = 
    SELECT cust.state, cust.gender, SUM(updt_ord.number_of_orders) AS number_of_orders_by_state
    FROM (SELECT ord.customer_id AS customer_id,COUNT(*) AS number_of_orders 
    FROM @orders AS ord
    GROUP BY ord.customer_id) AS updt_ord
    INNER JOIN @customers AS cust
    ON updt_ord.customer_id == cust.customer_id
    GROUP BY cust.state,cust.gender;

OUTPUT @age_wise_exp_dist_result_2
    TO "wasb://publish@storage_account_name.blob.core.windows.net/age_wise_expenditure_distribution.csv"
    ORDER BY customer_name
    USING Outputters.Csv();

OUTPUT @big_spenders_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/big_spenders.csv"
    ORDER BY number_of_orders DESC
    USING Outputters.Csv();

OUTPUT @gender_orders_by_month_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/gender_orders_by_month.csv"
    USING Outputters.Csv();

OUTPUT @gender_product_category_count_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/gender_product_category_count.csv"
    ORDER BY product_category
    USING Outputters.Csv();

OUTPUT @house_hold_income_distribution_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/house_hold_income_distribution.csv"
    USING Outputters.Csv();

OUTPUT @loyal_customer_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/loyal_customer.csv"
    ORDER BY DaysAsCustomer
    USING Outputters.Csv();

OUTPUT @order_distribution_by_day_of_week_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/order_distribution_by_day_of_week.csv"
    ORDER BY day_of_week
    USING Outputters.Csv();

OUTPUT @payment_type_result   
    TO "wasb://publish@storage_account_name.blob.core.windows.net/payment_type.csv"
    USING Outputters.Csv();

OUTPUT @state_wise_order_distribution_result
    TO "wasb://publish@storage_account_name.blob.core.windows.net/state_wise_order_distribution.csv"
    ORDER BY number_of_orders_by_state, state, gender DESC
    USING Outputters.Csv();
    