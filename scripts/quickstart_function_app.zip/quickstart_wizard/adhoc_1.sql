@orders  =
    EXTRACT customer_id string, sku string, order_date  DateTime, product_quantity    string, amount_spent    float, latitude   string, longitude   string, payment_mode    string
    FROM "wasb://transformed@storage_account_name.blob.core.windows.net/datasets/orders/{*}.csv"
    USING Extractors.Csv(skipFirstNRows:1);
@rs1=
    SELECT updt_date.order_date.Hour AS hour_of_day, COUNT(*) AS count
    FROM (SELECT (DateTime)order_date AS order_date FROM @orders) AS updt_date
    GROUP BY updt_date.order_date.Hour;
OUTPUT @rs1
    TO "wasb://publish@storage_account_name.blob.core.windows.net/datasets/adhoc/ADHOC_1_Hour_of_the_day.csv"
    ORDER BY hour_of_day ASC
    USING Outputters.Csv(outputHeader: true);