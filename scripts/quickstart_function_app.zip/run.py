import os
import json, time
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))

import requests
import uuid
from azure.mgmt.datalake.analytics.job.models import JobInformation, JobState, USqlJobProperties
from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.datalake.analytics.job import DataLakeAnalyticsJobManagementClient

from utilities import df_run_id, df_status, adla_run_job_status,run_stream_job

response = open(os.environ['res'], 'w')
env = os.environ
function_app_name = env['function_app_name']
discover_raw_dataset_run_id = 0
transformed_dataset_run_id = 0
function_app_url = '"https://' + function_app_name + '.azurewebsites.net/api/quickstart_wizard"'
get_token_app_url = '"https://' + function_app_name + '.azurewebsites.net/api/get_token_using_username_and_pwd"'


# Get HTTP METHOD
http_method = env['REQ_METHOD'] if 'REQ_METHOD' in env else "GET"
#print http_method

if http_method == 'GET':
    with open('index.html', 'r') as f:
        html_in_string_format = f.read()
        returnData = {
            # HTTP Status Code:
            "status": 200,

            # Response Body:
            # "body":"process done",
            "body": html_in_string_format.replace('next_function_route', function_app_url),

            # Send any number of HTTP headers
            "headers": {
            "Content-Type": "text/html",
            "X-Awesome-Header": "YesItIs"
        }
        }
        response.write(json.dumps(returnData))

if http_method == 'POST':
    b = open(os.environ['req']).read() if os.environ['req'] else "'a':'b'"
    l = b.split('=')
    print(len(l))

    if len(l) == 2 :
        a = '{"' + l[0] + '":"' + l[1] + '"}'
    if len(l) > 2 :
        c = str(l[1]).split('&')
        print(len(c))
        a = '{"' + l[0] + '":"' + c[0]  +'","'+ c[1] + '":"' + l[2]+'"}'
    print(a)
    postreqdata = json.loads(a)

    if postreqdata['name'] == 'discover_raw_datasets':
        with open('discover_raw_datasets.html', 'r') as f:
            html_in_string_format = f.read()
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": html_in_string_format.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))


    elif postreqdata['name'] == 'transform_dataset':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        df_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelines/pipelineForDataTransformation/createRun?api-version=2017-09-01-preview"
        run_id_json = df_run_id(df_url,app_id,app_secret,tenant)
        jsonresponse = run_id_json.json()
        run_id = jsonresponse['runId']
        response.write(run_id)

    elif postreqdata['name'] == 'adla':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        tenant = env['tenant']
        adla_account_name = env['adla_account_name']
        usql_script = ""
        with open('order_data.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            usql_script =script.replace('storage_account_name',env['storage_name'])

        with open('run_analytics_job.html', 'r') as f:
            html_in_string_format = f.read()
            portal_adal_url= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.DataLakeAnalytics/accounts/'+adla_account_name+'/overview\''
            new_str = html_in_string_format.replace('portal_adal_url', portal_adal_url)
            html_str = new_str.replace('query_place_holder',usql_script)
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": html_str.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'js_sender':   
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        tenant = env['tenant'] 
        storage_name=env['storage_name']
        eventhub_name=env['eventhub_name']
        eventhub_namespace=env['eventhub_namespace']
        sas_key=env['sas_key']
        a = requests.get('https://'+storage_name+'.blob.core.windows.net/web-ui/angular/views/eventhubdemoV3.html', allow_redirects=True)
        s = a.content
        portal_stream_analytics_url_1= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/ageGroupWiseRevenueJob/outputs\''
        portal_stream_analytics_url_2= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/cleanOrdersStreamAnalyticsJob/outputs\''
        portal_stream_analytics_url_3= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/geoLocationsJob/outputs\''
        portal_stream_analytics_url_4= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/sellingProductPerMinJob/outputs\''
        t = s.replace('portal_stream_analytics_url_1',portal_stream_analytics_url_1).replace('portal_stream_analytics_url_2',portal_stream_analytics_url_2).replace('portal_stream_analytics_url_3',portal_stream_analytics_url_3).replace('portal_stream_analytics_url_4',portal_stream_analytics_url_4)        
        b = t.replace('eventHubHolder','"'+eventhub_name+'"').replace('storage_account_name',storage_name)
        c = b.replace('SASKeyHolder','"'+sas_key+'"')
        d = c.replace('ehNamespaceName','"'+eventhub_namespace+'"')
        e = d.replace('next_function_route',function_app_url)
        returnData = {
            # HTTP Status Code:
            "status": 200,

            # Response Body:
            # "body":"process done",
            "body":e,

            # Send any number of HTTP headers
            "headers": {
            "Content-Type": "text/html",
            "X-Awesome-Header": "YesItIs"
        }
        }
        # print 'first'
        response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'adhoc':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        tenant = env['tenant']
        adla_account_name = env['adla_account_name']
        adhoc_1_usql_script = ""
        adhoc_2_usql_script = ""
        adhoc_3_usql_script = ""  
        with open('adhoc_1.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            adhoc_1_usql_script = script.replace('storage_account_name',env['storage_name'])
        with open('adhoc_2.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            adhoc_2_usql_script = script.replace('storage_account_name',env['storage_name'])
        with open('adhoc_3.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            adhoc_3_usql_script = script.replace('storage_account_name',env['storage_name'])  
        with open('adhoc_analytics.html', 'r') as f:
            html_in_string_format = f.read()
            portal_adal_url= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.DataLakeAnalytics/accounts/'+adla_account_name+'/overview\''
            new_str = html_in_string_format.replace('portal_adal_url', portal_adal_url)
            html_str = new_str.replace('adhoc_1_query_place_holder',adhoc_1_usql_script).replace('adhoc_2_query_place_holder',adhoc_2_usql_script).replace('adhoc_3_query_place_holder',adhoc_3_usql_script)        
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                # "body":"process done",
                "body": html_str.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                "Content-Type": "text/html",
                "X-Awesome-Header": "YesItIs"
            }
            }
            response.write(json.dumps(returnData))
    
    elif postreqdata['name'] == 'powerbi':        
        with open('power_bi_details.html', 'r') as f:
            html_in_string_format = f.read()
            powerbi_online_portal_url = '\'https://powerbi.microsoft.com\''
            new_str = html_in_string_format.replace('powerbi_online_portal_url',powerbi_online_portal_url)          
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                # "body":"process done",
                "body": new_str.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                "Content-Type": "text/html",
                "X-Awesome-Header": "YesItIs"
            }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'run_stream_analytics_job':
        sub_id = env['subscription_id']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        rg_name = env['resource_group']

        run_stream_job("start","cleanOrdersStreamAnalyticsJob",sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("start","ageGroupWiseRevenueJob",sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("start","geoLocationsJob",sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("start","sellingProductPerMinJob",sub_id,rg_name,app_id,app_secret,tenant)
        response.write("Job started")

    elif postreqdata['name'] == 'stop_stream_analytics_job':
        sub_id = env['subscription_id']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        rg_name = env['resource_group']

        run_stream_job("stop","cleanOrdersStreamAnalyticsJob",sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("stop","ageGroupWiseRevenueJob",sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("stop","geoLocationsJob",sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("stop","sellingProductPerMinJob",sub_id,rg_name,app_id,app_secret,tenant)
        response.write("Job stopped")

    elif postreqdata['name'] == 'publish_dataset':
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        token_1 = postreqdata['token']
        headers ={'Authorization': 'Bearer ' + token_1, 'Content-Type': 'application/json'}
        usql_script=""

        with open('order_data.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            usql_script =script.replace('storage_account_name',env['storage_name'])  
        
        guid=uuid.uuid4()
        data = {
            "jobId": str(guid),
            "name": "yashadlajob",
            "type": "USql",
            "degreeOfParallelism": 1,
            "priority": 1000,
            "properties": {
                "type": "USql",
                "script": usql_script
            }
        }

        url = "https://quickstartadla.azuredatalakeanalytics.net/jobs/"+str(guid)+"?api-version=2016-11-01"
        
        res = requests.put(url,data=json.dumps(data), headers=headers)
        response.write(str(guid))

    elif postreqdata['name'] == 'get_dataset':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        
        df_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelines/pipelineForDataMovement/createRun?api-version=2017-09-01-preview"
        run_id_json = df_run_id(df_url,app_id,app_secret,tenant)
        jsonresponse = run_id_json.json()
        run_id = jsonresponse['runId']
        time.sleep(90)
        req_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelineruns/" + str(run_id) + "?api-version=2017-09-01-preview"
        df_st = df_status(req_url,app_id,app_secret,tenant)

        while True:
            if df_st not in 'InProgress':
                break
            df_st = df_status(req_url,app_id,app_secret,tenant)
                                 
        with open('create_transform_datasets.html', 'r') as f:
            html_in_string_format = str(f.read())
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": html_in_string_format.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }

        response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'df_status':
        sub_id = env['subscription_id']
        run_id = postreqdata['run_id']
        print run_id
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        req_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelineruns/" + str(run_id) + "?api-version=2017-09-01-preview"
        df_st = df_status(req_url,app_id,app_secret,tenant)
        response.write(df_st)
    
    elif postreqdata['name'] == 'adla_status':
        job_id = postreqdata['run_id']
        adla_account_name = env['adla_account_name']

        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']

        jobResult = adla_run_job_status(job_id,adla_account_name,app_id,app_secret,tenant)
        
        response.write(str(jobResult.state))

    else:
        response.write('invalid request')

response.close()


