


import json
import urllib
import os
import datetime
import sys, os.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests

# postreqdata = json.loads(open(os.environ['req']).read())

# response = open(os.environ['res'], 'w')

batch_index = 'batch-metadata'
stream_index = 'stream-metadata'

batchDashboardJSON= [
                      {
                        "_id": "Batch-Data-Lake-Metadata",
                        "_type": "dashboard",
                        "_source": {
                          "title": "Batch Data Lake Metadata",
                          "hits": 0,
                          "description": "",
                          "panelsJSON": "[{\"col\":1,\"id\":\"Raw-Size\",\"panelIndex\":1,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":4,\"id\":\"Transformed-Datasets-Size\",\"panelIndex\":2,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":7,\"id\":\"Published-Data-Size\",\"panelIndex\":3,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":10,\"id\":\"Combined-Size\",\"panelIndex\":4,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":1,\"id\":\"Raw-Count\",\"panelIndex\":5,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":4,\"id\":\"Transformed-Datasets-Count\",\"panelIndex\":6,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":7,\"id\":\"Published-Data-Count\",\"panelIndex\":7,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":10,\"id\":\"Combined-Count\",\"panelIndex\":8,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":1,\"id\":\"Top-Raw-Summary\",\"panelIndex\":9,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":4,\"id\":\"Top-Transformed-Datasets-Summary\",\"panelIndex\":10,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":7,\"id\":\"Top-Published-Data-Summary\",\"panelIndex\":11,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":10,\"id\":\"Top-Combined-Summary\",\"panelIndex\":12,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"}]",
                          "optionsJSON": "{\"darkTheme\":false}",
                          "uiStateJSON": "{\"P-10\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}},\"P-11\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}},\"P-12\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}},\"P-5\":{\"vis\":{\"legendOpen\":false}},\"P-6\":{\"vis\":{\"legendOpen\":false}},\"P-7\":{\"vis\":{\"legendOpen\":false}},\"P-8\":{\"vis\":{\"legendOpen\":false}},\"P-9\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}}",
                          "version": 1,
                          "timeRestore": "false",
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"filter\":[{\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"_index: batch-metadata\"}}}]}"
                          }
                        }
                      },
                      {
                        "_id": "Combined-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Combined Count",
                          "visState": "{\"title\":\"Combined Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Combined-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Combined Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Combined Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"*\"}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Combined-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Combined Size",
                          "visState": "{\"title\":\"Combined Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Published-Data-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Published Data Count",
                          "visState": "{\"title\":\"Published Data Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: published\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Published-Data-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Published Data Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Published Data Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: published\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Transformed-Datasets-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Transformed Dataset Size",
                          "visState": "{\"title\":\"Transformed Dataset Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: transformed\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Published-Data-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Published Data Size",
                          "visState": "{\"title\":\"Published Data Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: published\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Raw-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Raw Dataset Size",
                          "visState": "{\"title\":\"Raw Dataset Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type:raw\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Raw-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Raw Dataset Count",
                          "visState": "{\"title\":\"Raw Dataset Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type:raw\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Transformed-Datasets-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Transformed Dataset Count",
                          "visState": "{\"title\":\"Transformed Dataset Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: transformed\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Transformed-Datasets-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Transformed Dataset Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Transformed Dataset Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: transformed\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Raw-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Raw Dataset Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Raw Dataset Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"_type:raw\"}},\"filter\":[]}"
                          }
                        }
                      }
                    ]


streamdashboardJSON = [
    {
        "_id": "Stream-Data-Lake-Metadata",
        "_type": "dashboard",
        "_source": {
            "title": "Stream Data Lake Metadata",
            "hits": 0,
            "description": "",
            "panelsJSON": "[{\"col\":1,\"id\":\"Geo-Location-of-customers\",\"panelIndex\":1,\"row\":1,\"size_x\":12,\"size_y\":4,\"type\":\"visualization\"},{\"col\":1,\"id\":\"TopSellingProduct\",\"panelIndex\":2,\"row\":5,\"size_x\":7,\"size_y\":4,\"type\":\"visualization\"},{\"id\":\"Age-Group-wise-Revenue\",\"type\":\"visualization\",\"panelIndex\":3,\"size_x\":5,\"size_y\":4,\"col\":8,\"row\":5}]",
            "optionsJSON": "{\"darkTheme\":false}",
            "uiStateJSON": "{\"P-1\":{\"mapCenter\":[37.64903402157866,-96.8994140625]}}",
            "version": 1,
            "timeRestore": "false",
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": "{\"filter\":[{\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"*\"}}}]}"
            }
        }
    },
    {
        "_id": "TopSellingProduct",
        "_type": "visualization",
        "_source": {
            "title": "TopSellingProduct",
            "visState": "{\"title\":\"TopSellingProduct\",\"type\":\"line\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"showCircles\":true,\"smoothLines\":false,\"interpolate\":\"linear\",\"scale\":\"linear\",\"drawLinesBetweenPoints\":true,\"radiusRatio\":9,\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"avg\",\"schema\":\"metric\",\"params\":{\"field\":\"COUNT_ORDERS\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"HOUR_MINUTE\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{},\"customLabel\":\"timestamp per minute\"}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"SKU.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
            "uiStateJSON": "{}",
            "description": "",
            "version": 1,
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": "{\"index\":\"stream-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
            }
        }
    },
    {
        "_id": "Geo-Location-of-customers",
        "_type": "visualization",
        "_source": {
            "title": "Geo-Location of customers",
            "visState": "{\"title\":\"Geo-Location of customers\",\"type\":\"tile_map\",\"params\":{\"mapType\":\"Scaled Circle Markers\",\"isDesaturated\":true,\"addTooltip\":true,\"heatMaxZoom\":16,\"heatMinOpacity\":0.1,\"heatRadius\":25,\"heatBlur\":15,\"heatNormalizeData\":true,\"legendPosition\":\"bottomright\",\"mapZoom\":2,\"mapCenter\":[15,5],\"wms\":{\"enabled\":true,\"url\":\"https://basemap.nationalmap.gov/arcgis/services/USGSTopo/MapServer/WMSServer\",\"options\":{\"version\":\"1.3.0\",\"layers\":\"0\",\"format\":\"image/png\",\"transparent\":true,\"attribution\":\"Maps provided by USGS\",\"styles\":\"\"}}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"geohash_grid\",\"schema\":\"segment\",\"params\":{\"field\":\"GEOLOCATION\",\"autoPrecision\":true}}],\"listeners\":{}}",
            "uiStateJSON": "{\"mapCenter\":[37.64903402157866,-96.94335937499999],\"mapZoom\":4}",
            "description": "",
            "version": 1,
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": "{\"index\":\"stream-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
            }
        }
    },
    {
        "_id": "Age-Group-wise-Revenue",
        "_type": "visualization",
        "_source": {
            "title": "Age Group wise Revenue",
            "visState": "{\"title\":\"Age Group wise Revenue\",\"type\":\"line\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"showCircles\":true,\"smoothLines\":false,\"interpolate\":\"linear\",\"scale\":\"linear\",\"drawLinesBetweenPoints\":true,\"radiusRatio\":9,\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"COUNT_CUSTOMERS\",\"customLabel\":\"Revenue\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"HOUR_MINUTE\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{},\"customLabel\":\"timestamp per minute\"}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"AGE_GRP_CATEGORY.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
            "uiStateJSON": "{}",
            "description": "",
            "version": 1,
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": "{\"index\":\"stream-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
            }
        }
    }
]

def addDashboard(metadataFromBlob):
    try:
        elasticsearchIp=os.environ['esIp']
        print(elasticsearchIp)
        esClient = Elasticsearch(
            hosts=[{'host': elasticsearchIp, 'port': 9200}],
        )
        print(esClient);

        visualizations = json.dumps(batchDashboardJSON)
        #	print(batchDashboardJSON)
        for visualization in batchDashboardJSON:
            esClient.index(
                index='.kibana',
                doc_type=visualization['_type'],
                id=visualization['_id'],
                body=json.dumps(visualization['_source'])
            )
            print(visualization['_source'])
        # Set Default Index
        esClient.index(index='.kibana', doc_type='config', id='5.1.1',
                       body=json.dumps({'defaultIndex': 'batch-metadata'}))
        kibana_index_batch = {'title': batch_index, 'timeFieldName': 'LastModified'}
        esClient.index(index='.kibana', doc_type='index-pattern', id='batch-metadata',
                       body=json.dumps(kibana_index_batch))

        for visualization in streamdashboardJSON:
            esClient.index(
                index='.kibana',
                doc_type=visualization['_type'],
                id=visualization['_id'],
                body=json.dumps(visualization['_source'])
            )
        addDataToKibana(metadataFromBlob)

    except Exception as E:
        print("Unable to Create Index {0}".format("batch-metadata"))
        print(E)
        exit(4)

def addDataToKibana(dataFromBlob):
    elasticsearchIp=os.environ['esIp']
    esClient = Elasticsearch(
        hosts=[{'host': elasticsearchIp, 'port': 9200}]
    )
    # #convert date object
    # lastModified=dataFromBlob['LastModified']
    # temp=lastModified.split(' ')
    # dataDate=temp[0]+' '+temp[1] #'6/27/2018 7:44:13'
    # print(dataDate)
    # datetime_object = datetime.datetime.strptime(dataDate, '%m/%d/%Y %H:%M:%S')
    # print(datetime_object)

    # #print ETag
    # key=dataFromBlob['Key']
    # ContentType=dataFromBlob['ContentType']
    # ETag=dataFromBlob['ETag']
    # ContentLength=dataFromBlob['ContentLength']
    # metadata=dataFromBlob['metadata']
    # SizeMB=dataFromBlob['SizeMiB']
    # Etag=dataFromBlob['ETag']
    # Dataset=dataFromBlob['Dataset']
    # docType=dataFromBlob['DocType']

    print("^^^^^^^^^^^^^^^^^^^^^",dataFromBlob)
    
    result=esClient.index(index='batch-metadata',doc_type=dataFromBlob['DocType'], body=json.dumps(dataFromBlob))
    print(result)

#metadataFromBlob=json.loads(open(os.environ['req']).read())


eventData=str(open(os.environ['req']).read());
eventMSG=json.loads(eventData)
dataFromBlob=eventMSG[0]
print("DATAFROMBLOG:--",dataFromBlob['data']['url'])
url=dataFromBlob['data']['url'].split('/')
if (len(url)==7):
    print("URLLLLLLLLLL---",url)
    key=url[6]
    ContentType=dataFromBlob['data']['contentType']
    ETag=dataFromBlob['data']['eTag']
    ContentLength=dataFromBlob['data']['contentLength']
    metadata={}
    SizeMB=(dataFromBlob['data']['contentLength'])/(1024*1024)
    Dataset=url[5]
    docType=url[3]

    data={
        "Key": key,
        "ContentType": ContentType,
        "LastModified": dataFromBlob['eventTime'],
        "ContentLength": ContentLength,
        "metadata": metadata,
        "SizeMiB": SizeMB,
        "ETag": ETag,
        "Dataset": Dataset,
        "DocType":docType
    }
    if Dataset=="orders" or Dataset=="customers" or Dataset=="demographics" or Dataset=="products":
        addDashboard(data)

#print('*********'+str(open(os.environ['req']).read()))
# eventMSG=str(open(os.environ['req']).read());
# d=json.loads(eventMSG)
# print(type(json.loads(eventMSG)))
# print("******",d[0]['data'])
