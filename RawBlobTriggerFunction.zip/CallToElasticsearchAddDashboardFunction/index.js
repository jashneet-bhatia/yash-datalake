var request=require('requests');
var http=require('http')


module.exports = function (context, myBlob) {



    var options = {

      host: process.env.kibanaFunctionHost,           
      path: process.env.kibanaFunctionPath, 
      method: "POST",
      headers : {
        "Content-Type":"application/json"
      }    
    };
   var requset = http.request(options, function(response) {
      var str = "";
      response.on("end", function (responseData) {
        print("**********",responseData)           
      });          
    });

    requset.write(myJSONObject);
    requset.end();
    requset.on('error', function(e) {
      console.error(e);
    });

};