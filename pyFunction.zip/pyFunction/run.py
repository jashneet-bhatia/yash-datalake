import os
import json


import sys, os.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'myenv/Lib/site-packages')))
import requests
import adal

#postreqdata = json.loads(open(os.environ['req']).read())
response = open(os.environ['res'], 'w')

authority_url = 'https://login.microsoftonline.com/638456b8-8343-4e48-9ebe-4f5cf9a1997d'
context = adal.AuthenticationContext(authority_url)
print(context)
resource = 'https://management.azure.com/'
client_id = '437d96a8-39ba-4d0b-bbb4-e7cb0bca1ee1'
client_secret = '1HFtXuPeOpprAtee9E6dGSSBC0WSNHHHqxrfX7XdMRA='
token = context.acquire_token_with_client_credentials(resource, client_id, client_secret)
print (token)

headers ={'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}

url = "https://management.azure.com/subscriptions/18bc600e-57c7-4ea5-b64a-bb62f1f34d2c/resourceGroups/innovationgroup-BigData/providers/Microsoft.DataFactory/factories/AerospacePMdf/pipelines/copyPipeline/createRun?api-version=2017-09-01-preview"
return_response = requests.post(url, headers=headers)

returnData = {
    #HTTP Status Code:
    "status": 200,
    
    #Response Body:
    "body": "<h1>Datafactory Triggered!</h1>",
    
    # Send any number of HTTP headers
    "headers": {
        "Content-Type": "text/html",
        "X-Awesome-Header": "YesItIs"
    }
}

response.write(json.dumps(returnData))
#response.write("datafactory triggered")

#print(r.status_code, r.reason)
#pprint.pprint(response.json())
response.close()